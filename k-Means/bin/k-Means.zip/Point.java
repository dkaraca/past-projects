
public class Point {
		double c1;
		double c2;
		double c3;
		double c4;
		String label;
		
		public Point(double co1, double co2, double co3, double co4){
			c1 = co1;
			c2 = co2;
			c3 = co3;
			c4 = co4;
			label = "";
		}
}
